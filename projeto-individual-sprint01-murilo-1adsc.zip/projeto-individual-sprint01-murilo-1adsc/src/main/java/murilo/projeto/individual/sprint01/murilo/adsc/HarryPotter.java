/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package murilo.projeto.individual.sprint01.murilo.adsc;

import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author murilo
 */

//OBS: A ordem das opções de menu não está de acordo com o PDF!
//Mas, possui todos os requisitos (Calculo, condicional, livre, game e sair)
public class HarryPotter {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        HarryPotterUtilities utilidadesHP = new HarryPotterUtilities();

        Integer menuDigitado = -1;

        long tempoTop1 = 1000000000;
        long tempoTop2 = 1000000000;
        long tempoTop3 = 1000000000;
        long tempoAgora = 1000000000;

        String nomeTop1 = "--";
        String nomeTop2 = "--";
        String nomeTop3 = "--";
        String nomeAgora = "--";

        while (menuDigitado != 5) {
            utilidadesHP.exibirMenu();
            menuDigitado = leitor.nextInt();

            switch (menuDigitado) {
                case 1:
                    System.out.println("\nQuantas questões você deseja treinar? (máximo 5)");
                    Integer qtdQuestoesTreino = leitor.nextInt();

                    while (qtdQuestoesTreino <= 0 || qtdQuestoesTreino > 5) {
                        System.out.println("Digite de 1 até 5");
                        qtdQuestoesTreino = leitor.nextInt();
                    }
                    utilidadesHP.treinarQuestoes(qtdQuestoesTreino);
                    break;
                case 2:
                    if (tempoAgora < tempoTop1) {
                        nomeTop3 = nomeTop2;
                        tempoTop3 = tempoTop2;

                        nomeTop2 = nomeTop1;
                        tempoTop2 = tempoTop1;

                        nomeTop1 = nomeAgora;
                        tempoTop1 = tempoAgora;
                    } else if (tempoAgora < tempoTop2) {
                        nomeTop3 = nomeTop2;
                        tempoTop3 = tempoTop2;

                        nomeTop2 = nomeAgora;
                        tempoTop2 = tempoAgora;
                    } else if (tempoAgora < tempoTop3) {
                        nomeTop3 = nomeAgora;
                        tempoTop3 = tempoAgora;
                    }

                    utilidadesHP.exibirRanking(nomeTop1, tempoTop1, nomeTop2, tempoTop2, nomeTop3, tempoTop3);
                    break;

                case 3:
                    utilidadesHP.exibirProbabilidadeCasa();
                    break;

                case 4:
                    System.out.println("\nDigite seu nome: ");
                    nomeAgora = leitor.next();

                    tempoAgora = utilidadesHP.championshipHP();
                    break;
                case 5:
                    break;
                default:
                    System.out.println("\n!Digite um numero que está no menu!\n");
                    break;
            }
            System.out.println("Até Mais!");

        }

        System.out.println("\n\nAVADA QUER TCHAAAAU!");
        System.out.println(
                "            _            _.,----,\n"
                + " __  _.-._ / '-.        -  ,._  \\) \n"
                + "|  `-)_   '-.   \\       / < _ )/\" }\n"
                + "/__    '-.   \\   '-, ___(c-(6)=(6)\n"
                + " , `'.    `._ '.  _,'   >\\    \"  )\n"
                + " :;;,,'-._   '---' (  ( \"/`. -='/\n"
                + ";:;;:;;,  '..__    ,`-.`)'- '--'\n"
                + ";';:;;;;;'-._ /'._|   Y/   _/' \\\n"
                + "      '''\"._ F    |  _/ _.'._   `\\\n"
                + "             L    \\   \\/     '._  \\\n"
                + "      .-,-,_ |     `.  `'---,  \\_ _|\n"
                + "      //    'L    /  \\,   (\"--',=`)7\n"
                + "     | `._       : _,  \\  /'`-._L,_'-._\n"
                + "     '--' '-.\\__/ _L   .`'         './/\n"
                + "                 [ (  /\n"
                + "                  ) `{\n"
                + "       snd        \\__)"
        );

    }
}
