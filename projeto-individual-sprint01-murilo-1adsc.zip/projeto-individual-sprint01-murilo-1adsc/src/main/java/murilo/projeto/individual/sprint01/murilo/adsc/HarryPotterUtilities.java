/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package murilo.projeto.individual.sprint01.murilo.adsc;

import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author murilo
 */
public class HarryPotterUtilities {

    void exibirMenu() {
        System.out.println("\n"
                + "-------------------------------\n"
                + "|  Harry Potter Championship  |\n"
                + "-------------------------------\n"
                + "|  Digite a opção desejada    |\n"
                + "-------------------------------\n"
                + "| 1 - Treine Questões         |\n"
                + "| 2 - Ver Ranking de Jogadores|\n"
                + "| 3 - Que casa eu sou?        |\n"
                + "| 4 - Start Championship      |\n"
                + "| 5 - Encerrar o Jogo         |\n"
                + "-------------------------------");
    }

    void treinarQuestoes(Integer qtdQuestoes) {

        for (int i = 1; i <= qtdQuestoes; i++) {
            Integer questaoSorteada = ThreadLocalRandom.current().nextInt(1, 11);

            switch (questaoSorteada) {
                case 1:
                    questaoTreino(i, "expelliarmus", "Que feitiço Harry usou para matar Lord Voldemort?");
                    break;
                case 2:
                    questaoTreino(i, "caldeirão", "O feitiço 'Felifors' transforma um gato em um quê?");
                    break;
                case 3:
                    questaoTreino(i, "coelho", " Qual Patronus pertence a Luna Lovegood?");
                    break;
                case 4:
                    questaoTreino(i, "terra", "Qual elemento está associado a Hufflepuff?");
                    break;
                case 5:
                    questaoTreino(i, "salazar", "Qual era o primeiro nome do fundador da casa da Sonserina?");
                    break;
                case 6:
                    questaoTreino(i, "apanhador", "Qual posição Harry joga em seu time de Quadribol?");
                    break;
                case 7:
                    questaoTreino(i, "gritar", "Quando desenterrada, uma mandrágora fará o quê?");
                    break;
                case 8:
                    questaoTreino(i, "rum", "Quem nocauteia o troll no banheiro feminino em Harry Potter e a Pedra Filosofal?");
                    break;
                case 9:
                    questaoTreino(i, "phoenix", "As lágrimas de qual animal são o único antídoto conhecido para o veneno do basilisco?");
                    break;
                case 10:
                    questaoTreino(i, "ravenclaw", "'A inteligência além da medida é o maior tesouro do homem' é o lema de qual casa?");
                    break;
            }

        }
        System.out.println(String.format("\n\nVocê treinou %d questões\n\n", qtdQuestoes));

    }

    void questaoTreino(Integer numeroQuestao, String respostaCerta, String Questao) {
        Scanner leitor = new Scanner(System.in);

        String respostaDigitada;
        Boolean naoAcertou = true;
        String querResposta;

        while (naoAcertou) {

            System.out.println(String.format("\nQuestão %d", numeroQuestao));
            System.out.println(Questao);
            respostaDigitada = leitor.nextLine().toLowerCase();

            if (respostaCerta.equals(respostaDigitada)) {
                naoAcertou = false;
                System.out.println("\nParabéns!\n");
            } else {
                System.out.println("\nVocê errou!");
                System.out.println("Quer a resposta? s/n");
                querResposta = leitor.nextLine().toLowerCase();
                System.out.println("");
                if (querResposta.equals("s")) {
                    System.out.println();
                    System.out.println(String.format("Resposta certa = %s\n", respostaCerta));
                    naoAcertou = false;
                }
            }

        }
    }

    long championshipHP() {
        Scanner leitor = new Scanner(System.in);

        System.out.println("\n\nBem Vindo ao Campeonato de HP!");
        System.out.println(
                "                                         _ __\n"
                + "        ___                             | '  \\\n"
                + "   ___  \\ /  ___         ,'\\_           | .-. \\        /|\n"
                + "   \\ /  | |,'__ \\  ,'\\_  |   \\          | | | |      ,' |_   /|\n"
                + " _ | |  | |\\/  \\ \\ |   \\ | |\\_|    _    | |_| |   _ '-. .-',' |_   _\n"
                + "// | |  | |____| | | |\\_|| |__    //    |     | ,'_`. | | '-. .-',' `. ,'\\_\n"
                + "\\\\_| |_,' .-, _  | | |   | |\\ \\  //    .| |\\_/ | / \\ || |   | | / |\\  \\|   \\\n"
                + " `-. .-'| |/ / | | | |   | | \\ \\//     |  |    | | | || |   | | | |_\\ || |\\_|\n"
                + "   | |  | || \\_| | | |   /_\\  \\ /      | |`    | | | || |   | | | .---'| |\n"
                + "   | |  | |\\___,_\\ /_\\ _      //       | |     | \\_/ || |   | | | |  /\\| |\n"
                + "   /_\\  | |           //_____//       .||`      `._,' | |   | | \\ `-' /| |\n"
                + "        /_\\           `------'        \\ |              `.\\  | |  `._,' /_\\\n"
                + "                                       \\|                    `.\\"
        );
        System.out.println("Você tem que responder 10 questões em menos tempo possível");
        System.out.println("Deseja começar? s/n");
        String comecarDigitado = leitor.nextLine();

        long start;
        long finish;
        long total = 0;
        long totalFormatado = 0;

        if (comecarDigitado.equals("s")) {
            start = System.currentTimeMillis();

            for (int i = 1; i <= 10; i++) {
                Integer questaoSorteada = ThreadLocalRandom.current().nextInt(1, 11);

                switch (questaoSorteada) {
                    case 1:
                        questaoOficial(i, "expelliarmus", "Que feitiço Harry usou para matar Lord Voldemort?");
                        break;
                    case 2:
                        questaoOficial(i, "caldeirão", "O feitiço 'Felifors' transforma um gato em um quê?");
                        break;
                    case 3:
                        questaoOficial(i, "coelho", " Qual Patronus pertence a Luna Lovegood?");
                        break;
                    case 4:
                        questaoOficial(i, "terra", "Qual elemento está associado a Hufflepuff?");
                        break;
                    case 5:
                        questaoTreino(i, "salazar", "Qual era o primeiro nome do fundador da casa da Sonserina?");
                        break;
                    case 6:
                        questaoOficial(i, "apanhador", "Qual posição Harry joga em seu time de Quadribol?");
                        break;
                    case 7:
                        questaoOficial(i, "gritar", "Quando desenterrada, uma mandrágora fará o quê?");
                        break;
                    case 8:
                        questaoOficial(i, "rum", "Quem nocauteia o troll no banheiro feminino em Harry Potter e a Pedra Filosofal?");
                        break;
                    case 9:
                        questaoOficial(i, "phoenix", "As lágrimas de qual animal são o único antídoto conhecido para o veneno do basilisco?");
                        break;
                    case 10:
                        questaoOficial(i, "ravenclaw", "'A inteligência além da medida é o maior tesouro do homem' é o lema de qual casa?");
                        break;
                }

            }

            finish = System.currentTimeMillis();
            total = finish - start;
            totalFormatado = total / 1000;

            System.out.println("EXPECTOOOOOOO ACABOUNOUNNNNNNNNN!");
            System.out.println(
                    "        ______\n"
                    + "        /      \\\n"
                    + "       |        |\n"
                    + "       |:/-\\\\--\\.\n"
                    + "        ( )-( )/,\n"
                    + "         | ,  .\n"
                    + "        / \\- /. \\\n"
                    + "       | ||L  / \\ \\\n"
                    + "      / /  \\/    | *\n"
                    + "     / /          \\  \\\n"
                    + "     | |      []   |\\ |\n"
                    + "    /| |           ||  |\n"
                    + "    || |           ||  |\n"
                    + "    |  |           ||  |\n"
                    + "    /_ |__________|||  |\n"
                    + "   /_ \\| ---------||   |\n"
                    + "   /_ / |         ||   |\n"
                    + "  /  | ||         | |     \n"
                    + "  \\//  ||         | |  |\n"
                    + "  /  | ||    T    | |  |\n"
                    + " /   | ||    |     |\n"
                    + "/     fog"
            );

            System.out.println(String.format(
                    "Parabéns, você demorou %d segundos", totalFormatado));
        } else {
            System.out.println("Ok, te vejo depois");
        }
        return totalFormatado;

    }

    void questaoOficial(Integer numeroQuestao, String respostaCerta, String Questao) {
        Scanner leitor = new Scanner(System.in);

        String respostaDigitada;
        Boolean naoAcertou = true;

        while (naoAcertou) {

            System.out.println(String.format("\nQuestão %d", numeroQuestao));
            System.out.println(Questao);
            respostaDigitada = leitor.nextLine().toLowerCase();

            if (respostaCerta.equals(respostaDigitada)) {
                naoAcertou = false;
                System.out.println("\nParabéns!\n");
            } else {
                System.out.println("\nVocê errou!");
                System.out.println("");
            }
        }

    }

    void exibirRanking(String nomeTop1, long tempoTop1, String nomeTop2, long tempoTop2, String nomeTop3, long tempoTop3) {

        System.out.println("\nTOP JOGADORES DO HARRY POTTER CHAMPIONSHIP");
        System.out.println("");
        System.out.println();
        System.out.println(String.format("1: - %s: %d segundos", nomeTop1, (tempoTop1 == 1000000000 ? -1 : tempoTop1)));
        System.out.println(String.format("2: - %s: %d segundos", nomeTop2, (tempoTop2 == 1000000000 ? -1 : tempoTop2)));
        System.out.println(String.format("3: - %s: %d segundos", nomeTop3, (tempoTop3 == 1000000000 ? -1 : tempoTop3)));
        System.out.println("");

        System.out.println(
                "   _____\n"
                + "  /     \\\n"
                + "/- (*) |*)\\\n"
                + "|/\\.  _>/\\|\n"
                + "    \\__/    |\\\n"
                + "   _| |_   \\-/\n"
                + "  /|\\__|\\  //\n"
                + " |/|   |\\\\//\n"
                + " |||   | ~'\n"
                + " ||| __|\n"
                + " /_\\| ||\n"
                + " \\_/| ||\n"
                + "   |7 |7\n"
                + "   || ||\n"
                + "   || ||\n"
                + "   /\\ \\ \\  fog\n"
                + "  ^^^^ ^^^"
        );

        System.out.println("");

    }

    void exibirProbabilidadeCasa() {
        Scanner leitor = new Scanner(System.in);

        System.out.println("\nOlá! Vamos Descobrir qual casa você pertence!");

        System.out.println("\n");
        System.out.println("O que você está mais ansioso para fazer?");
        System.out.println("A - Quero explorar esse códigos, sem dúvidas.");
        System.out.println("B - Mal posso esperar para a professora passar novos conteúdos");

        String pergunta01 = leitor.next().toLowerCase();

        while (!pergunta01.equals("a") && !pergunta01.equals("b")) {
            System.out.println("Digite uma alternativa existente!");
            pergunta01 = leitor.next().toLowerCase();
        }

        System.out.println("\n");
        System.out.println("Qual qualidade combina mais com você?");
        System.out.println("A - Curiosidade");
        System.out.println("B - Lealdade ");
        System.out.println("C - Ambição ");
        System.out.println("D - Coragem ");
        String pergunta02 = leitor.next().toLowerCase();

        while (!pergunta02.equals("a") && !pergunta02.equals("b")
                && !pergunta02.equals("c") && !pergunta02.equals("d")) {
            System.out.println("Digite uma alternativa existente!");
            pergunta02 = leitor.next().toLowerCase();
        }

        Integer porcentagemCorvinal = 0;
        Integer porcentagemLufa = 0;
        Integer porcentagemSonserina = 0;
        Integer porcentagemGrifinoria = 0;

        switch (pergunta01) {
            case "a":
                porcentagemSonserina += 25;
                porcentagemGrifinoria += 25;
                break;
            case "b":
                porcentagemLufa += 25;
                porcentagemCorvinal += 25;
                break;
        }

        switch (pergunta02) {
            case "a":
                porcentagemCorvinal += 50;
                break;
            case "b":
                porcentagemLufa += 50;
                break;
            case "c":
                porcentagemSonserina += 50;
                break;
            case "d":
                porcentagemGrifinoria += 50;
                break;
        }

        System.out.println("");
        if (porcentagemCorvinal >= 50) {
            System.out.println(String.format("Você tem %d%% de probabilidade de ser corvinal!", porcentagemCorvinal));

        } else if (porcentagemGrifinoria >= 50) {
            System.out.println(String.format("Você tem %d%% de probabilidade de ser grifinória!", porcentagemGrifinoria));

        } else if (porcentagemSonserina >= 50) {
            System.out.println(String.format("Você tem %d%% de probabilidade de ser sonserina!", porcentagemSonserina));
        } else if (porcentagemLufa >= 50) {
            System.out.println(String.format("Você tem %d%% de probabilidade de ser lufa-lufa!", porcentagemLufa));

        }

    }
}
