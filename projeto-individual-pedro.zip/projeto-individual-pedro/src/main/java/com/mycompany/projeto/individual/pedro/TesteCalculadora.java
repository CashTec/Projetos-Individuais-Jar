/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto.individual.pedro;



/**
 *
 * @author pedro
 */
public class TesteCalculadora {
    
    public static void main(String[] args) {
    MenuOpcoes opcoes = new MenuOpcoes();
    opcoes.exibirMenu();
    }

    
    
    
}
