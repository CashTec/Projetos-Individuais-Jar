/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto.individual.pedro;

import java.time.LocalTime;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author pedro
 */
public class MenuOpcoes {

    void exibirMenu() {
        Scanner leitor = new Scanner(System.in);
        Integer opcao = -1;
        System.out.println("---------- ESCOLHA UMA OPCÃO --------------\n 1-Ver média das provas\n 2- Qual foi o seu desempenho\n 3- Guia de estudos \n 4-Sair");
        opcao = leitor.nextInt();

        while (opcao <= 0 || opcao > 5) {
            System.out.println("Valor inserido invalido! Tente novamente");
            System.out.println("---------- ESCOLHA UMA OPCÃO --------------\n 1-Ver média das provas\n 2- Qual foi o seu desempenho\n 3- Guia de estudos \n 4-Sair");
            opcao = leitor.nextInt();
        }

        while (opcao != 4) {
            switch (opcao) {
                case 1:
                    calcularMedia();
                    break;

                case 2:
                     exibirDesempenhoGeral();
                    break;

                case 3:
                   
                    exibirGuiaEstudos();
                    break;

            }
        
            System.out.println("---------- ESCOLHA UMA OPCÃO --------------\n 1-Ver média das provas\n 2- Qual foi o seu desempenho\n 3- Guia de estudos \n 4-Sair");
            opcao = leitor.nextInt();
        }

    }

    void calcularMedia() {
        Scanner leitor = new Scanner(System.in);
        Integer opcaoMateria = -1;
        System.out.println("Informe qual máteria deseja calcular a média:\n1 - Análise de Sistemas\n2 - Sistemas Operacionais\n3- Linguagem de Programação ");
        opcaoMateria = leitor.nextInt();

        while (opcaoMateria <= 0 || opcaoMateria > 5) {
            System.out.println("Opção inválida! Tente novamente");
            System.out.println("Informe qual máteria deseja calcular a média:\n1 - Análise de Sistemas\n2 - Sistemas Operacionais\n3- Linguagem de Programação ");
            opcaoMateria = leitor.nextInt();
        }
        String materiaEscolhida = null;
        switch (opcaoMateria) {
            case 1:
                materiaEscolhida = "Análise de Sistemas";
                break;

            case 2:
                materiaEscolhida = "Sistemas Operacionais";
                break;

            case 3:
                materiaEscolhida = "Linguagem de Programação";
                break;
        }

        System.out.println("Informe sua nota de entrega");
        Double notaEntrega = leitor.nextDouble();

        System.out.println("Informe sua nota da integradinha");
        Double notaIntegradinha = leitor.nextDouble();

        System.out.println("Informe sua nota da prova");
        Double notaProva = leitor.nextDouble();

        Double mediaNota = (notaEntrega * 0.3 + notaIntegradinha * 0.3 + notaProva * 0.4);

        String frase = String.format("Sua média em %s foi de %.2f", materiaEscolhida, mediaNota);
        System.out.println(frase);
    }

    void exibirDesempenhoGeral() {
        Scanner leitor = new Scanner(System.in);
        Double mediaGeral = 0.0;
        System.out.println("Informe a média da suas notas em suas respectivas materias: ");
        System.out.println("Análise de Sistemas|: ");
        mediaGeral += leitor.nextDouble();

        System.out.println("Sistema Operacionais: ");
        mediaGeral += leitor.nextDouble();

        System.out.println("Linguagem de Programação|: ");
        mediaGeral += leitor.nextDouble();

        mediaGeral = mediaGeral / 3;

        if (mediaGeral >= 9) {
            System.out.println(String.format("Que incrivel! Você tirou %.2f de média. Você foi muito bem nessa Sprint, continue assim e você vai longe!", mediaGeral));
        } else if (mediaGeral >= 6) {
            System.out.println(String.format("Parabéns, você ficou com %.2f na média geral e chegou ao seu objetivo. Continue assim para superar seus limites", mediaGeral));
        } else if (mediaGeral >= 3) {
            System.out.println(String.format("Você ficou com %.2f na média geral. Uma nota não te define. Continue estudando para superar esse desempenho", mediaGeral));
        } else {
            System.out.println(String.format("Você ficou com %.2f na média geral. Aconselho dar uma olhadinha no Guia de Estudos", mediaGeral));
        }
    }

    void exibirGuiaEstudos() {
        Scanner leitor = new Scanner(System.in);
        Integer opcaoMateria = -1;
        System.out.println("Informe qual máteria deseja estudar melhor\n1 - Análise de Sistemas\n2 - Sistemas Operacionais\n3- Linguagem de Programação ");
        opcaoMateria = leitor.nextInt();
        while (opcaoMateria <= 0 || opcaoMateria > 5) {
            System.out.println("Opção inválida! Tente novamente");
            System.out.println("Informe qual máteria deseja calcular a média:\n1 - Análise de Sistemas\n2 - Sistemas Operacionais\n3- Linguagem de Programação ");
            opcaoMateria = leitor.nextInt();
        }
        String materiaEscolhida = null;
        String conteudoEstudar = null;
        switch (opcaoMateria) {
            case 1:
                materiaEscolhida = "Análise de Sistemas";
                conteudoEstudar = " - LeanX Canvas(Aula 2)  \n -UserStories(Aula 3) - \n  Detalhamento de Requisitos(Aula 2 , Rever Conteudo do 1 Semestre - TI) ";
                break;

            case 2:
                materiaEscolhida = "Sistemas Operacionais";
                conteudoEstudar = " - O que é abstração de recursos (Aula 13/02 - Abstração de recurso)  \n - Comandos Linux para ver informações do Hardware(Aula 3) \n - Comandos e Fluxo para criar um usuário no Linux(Aula 27/03 - Comandos Linux, Exercício 3 - Comandos Linux) \n 4 - O que é WSL e como Instala-lo? (Aula 27/03 - VM e WSL) ";
                break;

            case 3:
                materiaEscolhida = "Linguagem de Programação";
                conteudoEstudar = "1- Diferença entre Classes do tipo Primitico e Wrapper (Aula 09/02/2023) \n  2 - Laços de repetição(Aula 16/02) \n 3 - Estruturas de repetição(Aula 16/02) \n 4 - Interpolação(Aula 16/02)";
                break;
        }

        String frase = String.format("Já que você esta precisando de ajuda em %s, sugiro estudar esse conteudos \n %s ", materiaEscolhida, conteudoEstudar);
        System.out.println(frase);
    }

}
